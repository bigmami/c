#include <stdio.h>
#include <stdlib.h>
double a;
int mod(int,int);
void ex5() {
	mod(17,5);
	
	printf("�l�ƬO:%lf",a );
}

int mod(int x,int y) {
	
	 x = 17;
	 y = 5;
	return a = x%y;
}