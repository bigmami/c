#include <stdio.h>
#include <stdlib.h>

void ex10_1() {

}