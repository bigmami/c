#include <stdio.h>
#include <stdlib.h>
#include <iostream> 
#include <string>
using namespace std;
main(void)
{
string str1("a");
string str2("b");
string str3("n");  
cout<<"�������^��O"<<str2+str1+str3+str1+str3+str1<<endl;
system("pause");

}
