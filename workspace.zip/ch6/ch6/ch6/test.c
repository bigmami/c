#include <stdlib.h>
#include <stdio.h>
void calculate();

void test(){
	calculate();
}

void calculate(){
	int a;
	printf("�п�J�@�Ӿ��\n");
	scanf("%d", &a);
	if (a> 60);
	printf("pass");
	printf("\n");
	if (a= 60);
	printf("down");
	printf("\n");
}