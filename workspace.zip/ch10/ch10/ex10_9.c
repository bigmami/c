#include <stdio.h>
#include <stdlib.h>

void ex10_9(){
	char str[10];
	printf("Please enter a string:");
	scanf("%s", str);
	printf("The string is %s\n", str);

}