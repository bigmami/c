#include <stdio.h>
#include <stdlib.h>
//#include <iostream>
//using namespace std;
int hw_6(){
	for(int i=1;i<10;i++){
		for(int k=1;k<10;k++){
			printf("%dX%d=%d\t",i,k,i*k);
			
			
		}
	}
	return 0;
}
