#include <stdio.h>
#include <stdlib.h>
//#include <iostream>
//using namespace std;


int hw_1(){
	int i,k;
	for (i = 2; i <= 6; i++){
		for (k =1; k <i; k++){
			printf("%d",k); 
		}
		printf("\n");
	}
return 0;
}
