#include <stdio.h>
#include <stdlib.h>
int main(void)
{
printf("Hello Every One, Welcome to the C World! ");
system("pause");
return 0;
}
