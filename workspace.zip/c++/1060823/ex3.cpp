#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int sum=1; 
for(int i=-1;i<100;i+=2) 
sum += i; 
printf("�`�M�O%d\n",sum); 
system("pause"); 

	
return 0;
}
