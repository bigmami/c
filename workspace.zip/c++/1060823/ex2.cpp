#include <stdio.h>
#include <stdlib.h>
#include <iostream>

using namespace std ;

int main()
{
	cout << "�������^��O" << endl
		 << "banana" << endl;
	system("pause");
	return 0;
 }
