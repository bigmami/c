#include <stdio.h>
#include <stdlib.h>
int main(void)
{
printf("Hello C!\n");
printf("Hello World!\n");
system("pause");
return 0;
}
