#include <stdio.h>
#include <stdlib.h>



void ex3_9(){
	int i,k;
	for (i = 1; i <= 5; i++){
		for (k = 1; k <= 5; k++){
			printf(k);
		}
		printf("\n");
	}

}


