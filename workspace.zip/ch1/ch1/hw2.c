#include <stdio.h>
#include <stdlib.h>
//#include <iostream> 
//#include <string>
//using namespace std;
int main(void)
{
	char x1='a';
	char x2= 'b';
	char x3= 'n';
	printf("�������^��O %c%c%c%c%c%c\n", x2, x1, x3, x1, x3, x1);
	//system("pause");
	return 0;
}
