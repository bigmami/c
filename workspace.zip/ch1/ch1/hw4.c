#include <stdio.h>
#include <stdlib.h>
void hw4(void)
{
	int sum = 0;
	for (int i = 0; i <= 10; i++)
		sum = sum + i*i;
	printf("�`�M�O%d\n",sum);
	system("pause");


	//return 0;
}