#include <stdio.h>
#include <stdlib.h>
void hw1(void)
{
	printf("Hello Every One, Welcome to the C World!\n");
	//system("pause");
	//return 0;
}